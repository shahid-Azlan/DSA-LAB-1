#include <iostream>
using namespace std;
int factorial(int* n) {
    int result = 1;
    for (int i = 1; i <= *n; i++) {
        result *= i;
    }
    return result;
}

int main() {
    int num;
    cout<<"Enter Number: ";
    cin >> num;

    int* ptr_num = &num;
    int result = factorial(ptr_num);

    cout << result << endl;

    return 0;
}

