#include <iostream>
using namespace std;
int main() {
    int arr[] = {5, 2, 9, 1, 7, 3, 8, 4, 6};
    int n = sizeof(arr) / sizeof(arr[0]);
    int *ptr = arr;
    int max_val = *ptr;
    int min_val = *ptr;

    for (int i = 1; i < n; i++) {
        if (*(ptr + i) > max_val) {
            max_val = *(ptr + i);
        }
        if (*(ptr + i) < min_val) {
            min_val = *(ptr + i);
        }
    }

    cout << "Maximum value: " << max_val << endl;
    cout << "Minimum value: " << min_val << endl;

    return 0;
}

