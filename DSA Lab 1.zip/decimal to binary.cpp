#include <iostream>
using namespace std;
void decimalToBinary(int n) {
    int binary[32];
    int* ptr = binary;

    int i = 0;
    while (n > 0) {
        *(ptr + i) = n % 2;
        n /= 2;
        i++;
    }

    for (int j = i - 1; j >= 0; j--) {
        cout << *(ptr + j);
    }
}

int main() {
    int decimal;
    cout<<"Enter Decimal Number: ";
    cin >> decimal;

    decimalToBinary(decimal);
    cout << endl;

    return 0;
}

