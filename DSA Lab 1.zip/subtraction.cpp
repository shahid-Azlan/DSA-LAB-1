#include <iostream>
using namespace std;
int main() {
    int a = 24, b = 12;
    int *ptr1 = &a, *ptr2 = &b;
    int result = *ptr1 - *ptr2;
    cout << "subtraction is: " << result << endl;
    cout << "Value of ptr1 is: "<<ptr1<<endl;
	cout << "Value of ptr2 is: "<<ptr2<<endl;
    return 0;
}

