#include <iostream>
using namespace std;
int main() {
    int a;
    int b;
    cout<<"Enter value of A: ";
    cin>>a;
    cout<<"Enter value of B: ";
    cin>>b;
    int *ptr1 = &a, *ptr2 = &b;
    if (*ptr1==*ptr2){
    cout<<"Both numbers are equal";
} else if (*ptr2<*ptr1){
	int d=*ptr1-*ptr2;
		cout<<"B is "<<d<<" times less than A";
	} 
	else{
	int	c=*ptr2-*ptr1;
		cout<<"A is "<<c<<" times less then B";
}
	cout << "\nValue of ptr1 is: "<<ptr1<<endl;
	cout << "\nValue of ptr2 is: "<<ptr2<<endl;
    return 0;
}

