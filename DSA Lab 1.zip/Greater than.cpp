#include <iostream>
using namespace std;
int main() {
    int a;
    int b;
    cout<<"Enter value of A :";
    cin>>a;
    cout<<"Enter value of B :";
    cin>>b;
    int *ptr1 = &a, *ptr2 = &b;
    if (*ptr1==*ptr2){
    cout<<"Both numbers are equal";
} else if (*ptr2>*ptr1){
	int d=*ptr2-*ptr1;
		cout<<"B is "<<d<<" greater than A";
	} 
	else{
	int	c=*ptr1-*ptr2;
		cout<<"A is "<<c<<" times greater then B";
}
	cout << "\nValue of ptr1 is: "<<ptr1<<endl;
	cout << "\nValue of ptr2 is: "<<ptr2<<endl;
    return 0;
}

