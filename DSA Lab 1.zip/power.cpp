#include <iostream>
using namespace std;
double power(double *base, int *exponent) {
    double result = 1.0;
    int exp = *exponent;

    if (exp >= 0) {
        for (int i = 0; i < exp; i++) {
            result *= *base;
        }
    } else {
        for (int i = 0; i < -exp; i++) {
            result /= *base;
        }
    }

    return result;
}

int main() {
    double base;
    int exponent;
	cout<<"Enter Number: ";
    cin >> base;
	cout<<"Enter Exponent: "; 
	cin >> exponent;
    double *ptr_base = &base;
    int *ptr_exponent = &exponent;

    double result = power(ptr_base, ptr_exponent);

    cout << "Result: " << result << endl;

    return 0;
}

