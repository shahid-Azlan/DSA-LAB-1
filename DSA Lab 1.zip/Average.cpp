#include <iostream>
using namespace std;
int main() {
    int a;
    int b;
    cout<<"Enter value of A: ";
    cin >> a;
    cout<<"Enter value of B: ";
    cin >> b;
    int *arr1 = &a;
    int *arr2 = &b;
    int sum = *arr1 + *arr2;
    float average=sum/2.0;
    cout << "Average: " << average << endl;
    return 0;
}

