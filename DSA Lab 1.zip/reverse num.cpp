#include <iostream>
using namespace std;
int main() {
    int a, b;
    cout <<"Enter First Number: ";
    cin >> a;
    cout <<"Enter Second Number: ";
    cin >> b;
    int* ptrA = &a;
    int* ptrB = &b;
    
    *ptrA = *ptrA + *ptrB;
    *ptrB = *ptrA - *ptrB;
    *ptrA = *ptrA - *ptrB;
    
    cout << "First Number: "<<*ptrA <<"\nSecond Number: "<<*ptrB << endl;
    
    return 0;
}

