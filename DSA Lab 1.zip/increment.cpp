#include <iostream>
using namespace std;
int main() {
    int x = 10;
    int* ptr = &x;
    *ptr += 5;
    cout <<"Value of x is: "<<x<< endl;
    cout <<"Value of increment x is: "<< *ptr << endl;
    cout <<"address of ptr is: "<< ptr << endl;
    return 0;
}

