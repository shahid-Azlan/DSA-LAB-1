#include <iostream>
using namespace std;
int main() {
    int a = 28, b = 7;
    int *ptr1 = &a, *ptr2 = &b;
    int result = *ptr1 / *ptr2;
    cout << "Division is: " << result << endl;
    cout << "Value of ptr1 is: "<<ptr1<<endl;
	cout << "Value of ptr2 is: "<<ptr2<<endl;
    return 0;
}

